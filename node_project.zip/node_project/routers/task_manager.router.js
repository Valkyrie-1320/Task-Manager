const router = require("express").Router();
const TaskManagerController = require('../controller/task_manager.controller');

router.post("/createTask", TaskManagerController.createTask);

router.get('/getUserTaskList', TaskManagerController.getUserTask);

router.post("/deleteTask", TaskManagerController.deleteTask);

module.exports = router;