const { deleteTask } = require("../controller/task_manager.controller");
const TaskManagerModel = require("../model/task_manager.model");


class TaskManagerService{
    static async createTask(userId,title,description){
            const createTask = new TaskManagerModel({userId, title, description});
            return await createTask.save();
    }

    static async getTaskData(userId){
        const taskdata = await TaskManagerModel.find({userId});
        return taskdata;
   }

   static async deleteTask(id){
        const deleted = await TaskManagerModel.findOneAndDelete({_id:id});
        return deleted;
   }
}

module.exports = TaskManagerService;