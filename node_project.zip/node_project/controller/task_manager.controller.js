const TaskManagerModel = require('../model/task_manager.model');
const TaskManagerService = require('../services/task_manager.services');

exports.createTask =  async (req, res, next)=>{
    try {
        const { userId, title, desc } = req.body;
        let task = await TaskManagerService.createTask(userId, title, desc);
        res.json({status: true, success: task});
    } catch (error) {
        console.log(error, 'err---->');
        next(error);
    }
}

exports.getUserTask =  async (req, res, next)=>{
    try {
        const {userId} = req.body;
        let task = await TaskManagerService.getTaskData(userId);
        res.json({status: true, success: task});
    } catch (error) {
        console.log(error, 'err---->');
        next(error);
    }
}

exports.deleteTask =  async (req, res, next)=>{
    try {
        const {id} = req.body;
        let deleted = await TaskManagerService.deleteTask(id);
        res.json({status: true, success: deleted});
    } catch (error) {
        console.log(error, 'err---->');
        next(error);
    }
}