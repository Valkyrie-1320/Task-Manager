const mongoose = require('mongoose');

const connection = mongoose.createConnection('mongodb://0.0.0.0:27017/task_manager').on('open', ()=>{
    console.log('MongoDB connected!');
}).on('error', ()=>{
    console.log('MongoDB connection error!')
});

module.exports = connection;